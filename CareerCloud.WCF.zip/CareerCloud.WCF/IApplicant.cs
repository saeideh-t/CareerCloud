﻿using CareerCloud.Pocos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace CareerCloud.WCF
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IApplicant
    {
        #region ApplicantEducation
        [OperationContract]
        void AddApplicantEducation(ApplicantEducationPoco[] items);

        [OperationContract]
        List<ApplicantEducationPoco> GetAllApplicantEducation();

        [OperationContract]
        ApplicantEducationPoco GetSingleApplicantEducation(Guid Id);

        [OperationContract]
        void RemoveApplicantEducation(ApplicantEducationPoco[] items);

        [OperationContract]
        void 	UpdateApplicantEducation(ApplicantEducationPoco[] items);

        #endregion


        #region ApplicantJobApplications
        [OperationContract]
        void AddApplicantJobApplication(ApplicantJobApplicationPoco[] items);

        [OperationContract]
        List<ApplicantJobApplicationPoco> GetAllApplicantJobApplication();

        [OperationContract]
        ApplicantJobApplicationPoco GetSingleApplicantJobApplication(Guid Id);

        [OperationContract]
        void RemoveApplicantJobApplication(ApplicantJobApplicationPoco[] items);

        [OperationContract]
        void UpdateApplicantJobApplication(ApplicantJobApplicationPoco[] items);

        #endregion


        #region ApplicantProfiles
        [OperationContract]
        void AddApplicantProfile(ApplicantProfilePoco[] items);

        [OperationContract]
        List<ApplicantProfilePoco> GetAllApplicantProfile();

        [OperationContract]
        ApplicantProfilePoco GetSingleApplicantProfile(Guid Id);

        [OperationContract]
        void RemoveApplicantProfile(ApplicantProfilePoco[] items);

        [OperationContract]
        void UpdateApplicantProfile(ApplicantProfilePoco[] items);

        #endregion


        #region ApplicantResumes
        [OperationContract]
        void AddApplicantResume(ApplicantResumePoco[] items);

        [OperationContract]
        List<ApplicantResumePoco> GetAllApplicantResume();

        [OperationContract]
        ApplicantResumePoco GetSingleApplicantResume(Guid Id);

        [OperationContract]
        void RemoveApplicantResume(ApplicantResumePoco[] items);

        [OperationContract]
        void UpdateApplicantResume(ApplicantResumePoco[] items);

        #endregion


        #region ApplicantSkills
        [OperationContract]
        void AddApplicantSkill(ApplicantSkillPoco[] items);

        [OperationContract]
        List<ApplicantSkillPoco> GetAllApplicantSkill();

        [OperationContract]
        ApplicantSkillPoco GetSingleApplicantSkill(Guid Id);

        [OperationContract]
        void RemoveApplicantSkill(ApplicantSkillPoco[] items);

        [OperationContract]
        void UpdateApplicantSkill(ApplicantSkillPoco[] items);

        #endregion


        #region ApplicantWorkHistory
        [OperationContract]
        void AddApplicantWorkHistory(ApplicantWorkHistoryPoco[] items);

        [OperationContract]
        List<ApplicantWorkHistoryPoco> GetAllApplicantWorkHistory();

        [OperationContract]
        ApplicantWorkHistoryPoco GetSingleApplicantWorkHistory(Guid Id);

        [OperationContract]
        void RemoveApplicantWorkHistory(ApplicantWorkHistoryPoco[] items);

        [OperationContract]
        void UpdateApplicantWorkHistory(ApplicantWorkHistoryPoco[] items);

        #endregion



    }



}
