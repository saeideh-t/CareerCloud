﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using CareerCloud.BusinessLogicLayer;
using CareerCloud.EntityFrameworkDataAccess;
using CareerCloud.Pocos;

namespace CareerCloud.WCF
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in both code and config file together.
    public class Applicant : IApplicant
    {
        private ApplicantEducationLogic _ApplicantEducationLogic;
        private ApplicantJobApplicationLogic _ApplicantJobApplicationLogic;
        private ApplicantProfileLogic _ApplicantProfileLogic;
        private ApplicantResumeLogic _ApplicantResumeLogic;
        private ApplicantSkillLogic _ApplicantSkillLogic;
        private ApplicantWorkHistoryLogic _ApplicantWorkHistoryLogic;

        public Applicant()
        {
            EFGenericRepository<ApplicantEducationPoco> ApplicantEducationRepo = new EFGenericRepository<ApplicantEducationPoco>(false);
            _ApplicantEducationLogic = new ApplicantEducationLogic(ApplicantEducationRepo);


            EFGenericRepository<ApplicantJobApplicationPoco> ApplicantJobApplicationRepo = new EFGenericRepository<ApplicantJobApplicationPoco>(false);
            _ApplicantJobApplicationLogic = new ApplicantJobApplicationLogic(ApplicantJobApplicationRepo);

            EFGenericRepository<ApplicantProfilePoco> ApplicantProfileRepo = new EFGenericRepository<ApplicantProfilePoco>(false);
            _ApplicantProfileLogic = new ApplicantProfileLogic(ApplicantProfileRepo);


            EFGenericRepository<ApplicantResumePoco> ApplicantResumeRepo = new EFGenericRepository<ApplicantResumePoco>(false);
            _ApplicantResumeLogic = new ApplicantResumeLogic(ApplicantResumeRepo);

            EFGenericRepository<ApplicantSkillPoco> ApplicantSkillRepo = new EFGenericRepository<ApplicantSkillPoco>(false);
            _ApplicantSkillLogic = new ApplicantSkillLogic(ApplicantSkillRepo);

            EFGenericRepository<ApplicantWorkHistoryPoco> ApplicantWorkHistoryRepo = new EFGenericRepository<ApplicantWorkHistoryPoco>(false);
            _ApplicantWorkHistoryLogic = new ApplicantWorkHistoryLogic(ApplicantWorkHistoryRepo);

        }

        #region ApplicantEducation
        public void AddApplicantEducation(ApplicantEducationPoco[] items)
        {
            _ApplicantEducationLogic.Add(items);
        }

        public List<ApplicantEducationPoco> GetAllApplicantEducation()
        {
            return _ApplicantEducationLogic.GetAll();
        }

        public ApplicantEducationPoco GetSingleApplicantEducation(Guid Id)
        {
            return _ApplicantEducationLogic.Get(Id);
        }

        public void RemoveApplicantEducation(ApplicantEducationPoco[] items)
        {
            _ApplicantEducationLogic.Delete(items);
        }

        public void UpdateApplicantEducation(ApplicantEducationPoco[] items)
        {
            _ApplicantEducationLogic.Update(items);
        }

        #endregion

        #region ApplicantJobApplications
        public void AddApplicantJobApplication(ApplicantJobApplicationPoco[] items)
        {
            _ApplicantJobApplicationLogic.Add(items);
        }

        public List<ApplicantJobApplicationPoco> GetAllApplicantJobApplication()
        {
            return _ApplicantJobApplicationLogic.GetAll();
        }

        public ApplicantJobApplicationPoco GetSingleApplicantJobApplication(Guid Id)
        {
            return _ApplicantJobApplicationLogic.Get(Id);
        }

        public void RemoveApplicantJobApplication(ApplicantJobApplicationPoco[] items)
        {
            _ApplicantJobApplicationLogic.Delete(items);
        }

        public void UpdateApplicantJobApplication(ApplicantJobApplicationPoco[] items)
        {
            _ApplicantJobApplicationLogic.Update(items);
        }

        #endregion

        #region ApplicantProfiles
        public void AddApplicantProfile(ApplicantProfilePoco[] items)
        {
            _ApplicantProfileLogic.Add(items);
        }

        public List<ApplicantProfilePoco> GetAllApplicantProfile()
        {
            return _ApplicantProfileLogic.GetAll();
        }

        public ApplicantProfilePoco GetSingleApplicantProfile(Guid Id)
        {
            return _ApplicantProfileLogic.Get(Id);
        }

        public void RemoveApplicantProfile(ApplicantProfilePoco[] items)
        {
            _ApplicantProfileLogic.Delete(items);
        }

        public void UpdateApplicantProfile(ApplicantProfilePoco[] items)
        {
            _ApplicantProfileLogic.Update(items);
        }

        #endregion

        #region ApplicantResumes
        public void AddApplicantResume(ApplicantResumePoco[] items)
        {
            _ApplicantResumeLogic.Add(items);
        }

        public List<ApplicantResumePoco> GetAllApplicantResume()
        {
            return _ApplicantResumeLogic.GetAll();
        }

        public ApplicantResumePoco GetSingleApplicantResume(Guid Id)
        {
            return _ApplicantResumeLogic.Get(Id);
        }

        public void RemoveApplicantResume(ApplicantResumePoco[] items)
        {
            _ApplicantResumeLogic.Delete(items);
        }

        public void UpdateApplicantResume(ApplicantResumePoco[] items)
        {
            _ApplicantResumeLogic.Update(items);
        }

        #endregion

        #region ApplicantSkills
        public void AddApplicantSkill(ApplicantSkillPoco[] items)
        {
            _ApplicantSkillLogic.Add(items);
        }

        public List<ApplicantSkillPoco> GetAllApplicantSkill()
        {
            return _ApplicantSkillLogic.GetAll();
        }

        public ApplicantSkillPoco GetSingleApplicantSkill(Guid Id)
        {
            return _ApplicantSkillLogic.Get(Id);
        }

        public void RemoveApplicantSkill(ApplicantSkillPoco[] items)
        {
            _ApplicantSkillLogic.Delete(items);
        }

        public void UpdateApplicantSkill(ApplicantSkillPoco[] items)
        {
            _ApplicantSkillLogic.Update(items);
        }

        #endregion

        #region ApplicantWorkHistory
        public void AddApplicantWorkHistory(ApplicantWorkHistoryPoco[] items)
        {
            _ApplicantWorkHistoryLogic.Add(items);
        }

        public List<ApplicantWorkHistoryPoco> GetAllApplicantWorkHistory()
        {
            return _ApplicantWorkHistoryLogic.GetAll();
        }

        public ApplicantWorkHistoryPoco GetSingleApplicantWorkHistory(Guid Id)
        {
            return _ApplicantWorkHistoryLogic.Get(Id);
        }

        public void RemoveApplicantWorkHistory(ApplicantWorkHistoryPoco[] items)
        {
            _ApplicantWorkHistoryLogic.Delete(items);
        }

        public void UpdateApplicantWorkHistory(ApplicantWorkHistoryPoco[] items)
        {
            _ApplicantWorkHistoryLogic.Update(items);
        }

        #endregion


    }
}
