﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using CareerCloud.BusinessLogicLayer;
using CareerCloud.EntityFrameworkDataAccess;
using CareerCloud.Pocos;

namespace CareerCloud.WCF
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Security" in both code and config file together.
    public class Security : ISecurity
    {
        private SecurityLoginLogic _SecurityLoginLogic;
        private SecurityLoginsLogLogic _SecurityLoginsLogLogic;
        
        private SecurityLoginsRoleLogic _SecurityLoginsRoleLogic;
       
        private SecurityRoleLogic _SecurityRoleLogic;
        public Security()
        {
            EFGenericRepository<SecurityLoginPoco> SecurityLoginRepo = new EFGenericRepository<SecurityLoginPoco>(false);
            _SecurityLoginLogic = new SecurityLoginLogic(SecurityLoginRepo);


            EFGenericRepository<SecurityLoginsLogPoco> SecurityLoginsLogRepo = new EFGenericRepository<SecurityLoginsLogPoco>(false);
            _SecurityLoginsLogLogic = new SecurityLoginsLogLogic(SecurityLoginsLogRepo);


            EFGenericRepository<SecurityLoginsRolePoco> SecurityLoginsRoleRepo = new EFGenericRepository<SecurityLoginsRolePoco>(false);
            _SecurityLoginsRoleLogic = new SecurityLoginsRoleLogic(SecurityLoginsRoleRepo);


            EFGenericRepository<SecurityRolePoco> SecurityRoleRepo = new EFGenericRepository<SecurityRolePoco>(false);
            _SecurityRoleLogic = new SecurityRoleLogic(SecurityRoleRepo);


        }
        public void AddSecurityLogin(SecurityLoginPoco[] items)
        {
            _SecurityLoginLogic.Add(items);
        }

        public void AddSecurityLoginsLog(SecurityLoginsLogPoco[] items)
        {
            _SecurityLoginsLogLogic.Add(items);
        }

        public void AddSecurityLoginsRole(SecurityLoginsRolePoco[] items)
        {
            _SecurityLoginsRoleLogic.Add(items);
        }

        public void AddSecurityRole(SecurityRolePoco[] items)
        {
            _SecurityRoleLogic.Add(items);
        }

        public List<SecurityLoginPoco> GetAllSecurityLogin()
        {
            return _SecurityLoginLogic.GetAll();
        }

        public List<SecurityLoginsLogPoco> GetAllSecurityLoginsLog()
        {
            return _SecurityLoginsLogLogic.GetAll();
        }

        public List<SecurityLoginsRolePoco> GetAllSecurityLoginsRole()
        {
            return _SecurityLoginsRoleLogic.GetAll();
        }

        public List<SecurityRolePoco> GetAllSecurityRole()
        {
            return _SecurityRoleLogic.GetAll();
        }

        public SecurityLoginPoco GetSingleSecurityLogin(String Id)
        {
            Guid GuidId = Guid.Parse(Id);
            return _SecurityLoginLogic.Get(GuidId);
        }

        public SecurityLoginsLogPoco GetSingleSecurityLoginsLog(string Id)
        {
            Guid GuidId = Guid.Parse(Id);
            return _SecurityLoginsLogLogic.Get(GuidId);
        }

        public SecurityLoginsRolePoco GetSingleSecurityLoginsRole(string Id)
        {
            Guid GuidId = Guid.Parse(Id);
            return _SecurityLoginsRoleLogic.Get(GuidId);
        }

        public SecurityRolePoco GetSingleSecurityRole(string Id)
        {
            Guid GuidId = Guid.Parse(Id);
            return _SecurityRoleLogic.Get(GuidId);
        }

        public void RemoveSecurityLogin(SecurityLoginPoco[] items)
        {
            _SecurityLoginLogic.Delete(items);
        }

        public void RemoveSecurityLoginsLog(SecurityLoginsLogPoco[] items)
        {
            _SecurityLoginsLogLogic.Delete(items);
        }

        public void RemoveSecurityLoginsRole(SecurityLoginsRolePoco[] items)
        {
            _SecurityLoginsRoleLogic.Delete(items);
        }

        public void RemoveSecurityRole(SecurityRolePoco[] items)
        {
            _SecurityRoleLogic.Delete(items);
        }

        public void UpdateSecurityLogin(SecurityLoginPoco[] items)
        {
            _SecurityLoginLogic.Update(items);
        }

        public void UpdateSecurityLoginsLog(SecurityLoginsLogPoco[] items)
        {
            _SecurityLoginsLogLogic.Update(items);
        }

        public void UpdateSecurityLoginsRole(SecurityLoginsRolePoco[] items)
        {
            _SecurityLoginsRoleLogic.Update(items);
        }

        public void UpdateSecurityRole(SecurityRolePoco[] items)
        {
            _SecurityRoleLogic.Update(items);
        }
    }
}
