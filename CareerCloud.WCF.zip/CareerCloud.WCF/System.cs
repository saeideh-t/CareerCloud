﻿using CareerCloud.BusinessLogicLayer;
using CareerCloud.EntityFrameworkDataAccess;
using CareerCloud.Pocos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace CareerCloud.WCF
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in both code and config file together.
    public class System : ISystem
    {
        private SystemCountryCodeLogic _SystemCountryCodeLogic;
        private SystemLanguageCodeLogic _SystemLanguageCodeLogic;
        public System()
        {
            EFGenericRepository<SystemCountryCodePoco> SystemCountryCodeRepo = new EFGenericRepository<SystemCountryCodePoco>(false);
            _SystemCountryCodeLogic = new SystemCountryCodeLogic(SystemCountryCodeRepo);


            EFGenericRepository<SystemLanguageCodePoco> SystemLanguageCodeRepo = new EFGenericRepository<SystemLanguageCodePoco>(false);
            _SystemLanguageCodeLogic = new SystemLanguageCodeLogic(SystemLanguageCodeRepo);

        }
        public void AddSystemCountryCode(SystemCountryCodePoco[] items)
        {
            _SystemCountryCodeLogic.Add(items);
        }

        public void AddSystemLanguageCode(SystemLanguageCodePoco[] items)
        {
            _SystemLanguageCodeLogic.Add(items);
        }

        public List<SystemCountryCodePoco> GetAllSystemCountryCode()
        {
            return _SystemCountryCodeLogic.GetAll();
        }

        public List<SystemLanguageCodePoco> GetAllSystemLanguageCode()
        {
            return _SystemLanguageCodeLogic.GetAll();
        }

        public SystemCountryCodePoco GetSingleSystemCountryCode(string Id)
        {
            return _SystemCountryCodeLogic.Get(Id);
        }

        public SystemLanguageCodePoco GetSingleSystemLanguageCode(string Id)
        {
            return _SystemLanguageCodeLogic.Get(Id);
        }

        public void RemoveSystemCountryCode(SystemCountryCodePoco[] items)
        {
            _SystemCountryCodeLogic.Delete(items);
        }

        public void RemoveSystemLanguageCode(SystemLanguageCodePoco[] items)
        {
            _SystemLanguageCodeLogic.Delete(items);
        }

        public void UpdateSystemCountryCode(SystemCountryCodePoco[] items)
        {
            _SystemCountryCodeLogic.Update(items);
        }

        public void UpdateSystemLanguageCode(SystemLanguageCodePoco[] items)
        {
            _SystemLanguageCodeLogic.Update(items);
        }
    }
}
