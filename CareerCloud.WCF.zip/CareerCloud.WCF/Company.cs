﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using CareerCloud.BusinessLogicLayer;
using CareerCloud.EntityFrameworkDataAccess;
using CareerCloud.Pocos;

namespace CareerCloud.WCF
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in both code and config file together.
    public class Company : ICompany
    {

        private CompanyDescriptionLogic _CompanyDescriptionLogic;
        private CompanyJobEducationLogic _CompanyJobEducationLogic;
        private CompanyJobSkillLogic _CompanyJobSkillLogic;
        private CompanyJobLogic _CompanyJobLogic;
        private CompanyJobDescriptionLogic _CompanyJobDescriptionLogic;
        private CompanyLocationLogic _CompanyLocationLogic;
        private CompanyProfileLogic _CompanyProfileLogic;

        public Company()
        {
            EFGenericRepository<CompanyDescriptionPoco> CompanyDescriptionRepo = new EFGenericRepository<CompanyDescriptionPoco>(false);
            _CompanyDescriptionLogic = new CompanyDescriptionLogic(CompanyDescriptionRepo);

            EFGenericRepository<CompanyJobEducationPoco> CompanyJobEducationRepo = new EFGenericRepository<CompanyJobEducationPoco>(false);
            _CompanyJobEducationLogic = new CompanyJobEducationLogic(CompanyJobEducationRepo);

            EFGenericRepository<CompanyJobSkillPoco> CompanyJobSkillRepo = new EFGenericRepository<CompanyJobSkillPoco>(false);
            _CompanyJobSkillLogic = new CompanyJobSkillLogic(CompanyJobSkillRepo);

            EFGenericRepository<CompanyJobPoco> CompanyJobRepo = new EFGenericRepository<CompanyJobPoco>(false);
            _CompanyJobLogic = new CompanyJobLogic(CompanyJobRepo);

            EFGenericRepository<CompanyJobDescriptionPoco> CompanyJobDescriptionRepo = new EFGenericRepository<CompanyJobDescriptionPoco>(false);
            _CompanyJobDescriptionLogic = new CompanyJobDescriptionLogic(CompanyJobDescriptionRepo);

            EFGenericRepository<CompanyLocationPoco> CompanyLocationRepo = new EFGenericRepository<CompanyLocationPoco>(false);
            _CompanyLocationLogic = new CompanyLocationLogic(CompanyLocationRepo);

            EFGenericRepository<CompanyProfilePoco> CompanyProfileRepo = new EFGenericRepository<CompanyProfilePoco>(false);
            _CompanyProfileLogic = new CompanyProfileLogic(CompanyProfileRepo);

        }

        #region Add
        public void AddCompanyDescription(CompanyDescriptionPoco[] items)
        {
            _CompanyDescriptionLogic.Add(items);
        }

        public void AddCompanyJobEducation(CompanyJobEducationPoco[] items)
        {
            _CompanyJobEducationLogic.Add(items);
        }

        public void AddCompanyJob(CompanyJobPoco[] items)
        {
            _CompanyJobLogic.Add(items);
        }

        public void AddCompanyJobDescription(CompanyJobDescriptionPoco[] items)
        {
            _CompanyJobDescriptionLogic.Add(items);
        }

        public void AddCompanyJobSkill(CompanyJobSkillPoco[] items)
        {
            _CompanyJobSkillLogic.Add(items);
        }

        public void AddCompanyLocation(CompanyLocationPoco[] items)
        {
            _CompanyLocationLogic.Add(items);
        }

        public void AddCompanyProfile(CompanyProfilePoco[] items)
        {
            _CompanyProfileLogic.Add(items);
        }
        #endregion

        #region GetAll
        public List<CompanyDescriptionPoco> GetAllCompanyDescription()
        {
            return _CompanyDescriptionLogic.GetAll();
        }

       
        public List<CompanyJobEducationPoco> GetAllCompanyJobEducation()
        {
            return _CompanyJobEducationLogic.GetAll();
        }

        public List<CompanyJobPoco> GetAllCompanyJob()
        {
            return _CompanyJobLogic.GetAll();
        }

        public List<CompanyJobDescriptionPoco> GetAllCompanyJobDescription()
        {
            return _CompanyJobDescriptionLogic.GetAll();
        }

        public List<CompanyJobSkillPoco> GetAllCompanyJobSkill()
        {
            return _CompanyJobSkillLogic.GetAll();
        }

        public List<CompanyLocationPoco> GetAllCompanyLocation()
        {
            return _CompanyLocationLogic.GetAll();
        }

        public List<CompanyProfilePoco> GetAllCompanyProfile()
        {
            return _CompanyProfileLogic.GetAll();
        }

        #endregion

        #region GetSingle
        public CompanyDescriptionPoco GetSingleCompanyDescription(Guid Id)
        {
            return _CompanyDescriptionLogic.Get(Id);
        }

        public CompanyJobEducationPoco GetSingleCompanyJobEducation(Guid Id)
        {
            return _CompanyJobEducationLogic.Get(Id);
        }

        public CompanyJobPoco GetSingleCompanyJob(Guid Id)
        {
            return _CompanyJobLogic.Get(Id);
        }

        public CompanyJobDescriptionPoco GetSingleCompanyJobDescription(Guid Id)
        {
            return _CompanyJobDescriptionLogic.Get(Id);
        }

        public CompanyJobSkillPoco GetSingleCompanyJobSkill(Guid Id)
        {
            return _CompanyJobSkillLogic.Get(Id);
        }

        public CompanyLocationPoco GetSingleCompanyLocation(Guid Id)
        {
            return _CompanyLocationLogic.Get(Id); throw new NotImplementedException();
        }

        public CompanyProfilePoco GetSingleCompanyProfile(Guid Id)
        {
            return _CompanyProfileLogic.Get(Id);
        }

        #endregion

        #region Remove
        public void RemoveCompanyDescription(CompanyDescriptionPoco[] items)
        {
            _CompanyDescriptionLogic.Delete(items);
        }

        public void RemoveCompanyJobEducation(CompanyJobEducationPoco[] items)
        {
            _CompanyJobEducationLogic.Delete(items);
        }

        public void RemoveCompanyJob(CompanyJobPoco[] items)
        {
            _CompanyJobLogic.Delete(items);
        }

        public void RemoveCompanyJobDescription(CompanyJobDescriptionPoco[] items)
        {
            _CompanyJobDescriptionLogic.Delete(items);
        }

        public void RemoveCompanyJobSkill(CompanyJobSkillPoco[] items)
        {
            _CompanyJobSkillLogic.Delete(items);
        }

        public void RemoveCompanyLocation(CompanyLocationPoco[] items)
        {
            _CompanyLocationLogic.Delete(items);
        }

        public void RemoveCompanyProfile(CompanyProfilePoco[] items)
        {
            _CompanyProfileLogic.Delete(items);
        }
        #endregion

        #region update
        public void UpdateCompanyDescription(CompanyDescriptionPoco[] items)
        {
            _CompanyDescriptionLogic.Update(items);
        }

        public void UpdateCompanyJobEducation(CompanyJobEducationPoco[] items)
        {
            _CompanyJobEducationLogic.Update(items);
        }

        public void UpdateCompanyJob(CompanyJobPoco[] items)
        {
            _CompanyJobLogic.Update(items);
        }

        public void UpdateCompanyJobDescription(CompanyJobDescriptionPoco[] items)
        {
            _CompanyJobDescriptionLogic.Update(items);
        }

        public void UpdateCompanyJobSkill(CompanyJobSkillPoco[] items)
        {
            _CompanyJobSkillLogic.Update(items);
        }

        public void UpdateCompanyLocation(CompanyLocationPoco[] items)
        {
            _CompanyLocationLogic.Update(items);
        }

        public void UpdateCompanyProfile(CompanyProfilePoco[] items)
        {
            _CompanyProfileLogic.Update(items);
        }

        #endregion
    }
}
