﻿using CareerCloud.Pocos;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareerCloud.EntityFrameworkDataAccess
{
   public class CareerCloudContext : DbContext
    {
        public DbSet<ApplicantEducationPoco> ApplicantEducations { get; set; }
        public DbSet<ApplicantJobApplicationPoco> ApplicantJobApplications { get; set; }
        public DbSet<ApplicantProfilePoco> ApplicantProfiles { get; set; }
        public DbSet<ApplicantResumePoco> ApplicantResumes { get; set; }
        public DbSet<ApplicantSkillPoco> ApplicantSkills { get; set; }
        public DbSet<ApplicantWorkHistoryPoco> ApplicantWorkHistories { get; set; }
        public DbSet<CompanyDescriptionPoco> CompanyDescriptions { get; set; }
        public DbSet <CompanyJobDescriptionPoco> CompanyJobDescriptions { get; set; }
        public DbSet <CompanyJobEducationPoco> CompanyJobEducations { get; set; }
        public DbSet<CompanyJobPoco> CompanyJobs { get; set; }
        public DbSet <CompanyJobSkillPoco> CompanyJobSkills { get; set; }
        public DbSet <CompanyLocationPoco> CompanyLocations { get; set; }
        public DbSet <CompanyProfilePoco> CompanyProfiles { get; set; }
        public DbSet <SecurityLoginPoco> SecurityLogins { get; set; }
        public DbSet <SecurityLoginsLogPoco> SecurityLoginsLog { get; set; }
        public DbSet <SecurityLoginsRolePoco> SecurityLoginsRoles { get; set; }
        public DbSet <SecurityRolePoco> SecurityRoles { get; set; }
        public DbSet <SystemCountryCodePoco> SystemCountryCodes { get; set; }
        public DbSet <SystemLanguageCodePoco> SystemLanguageCodes { get; set; }

        public CareerCloudContext(bool createProxy=true):base(@"Data Source=DESKTOP-GOF3DI9\HUMBERBRIDGING;Initial Catalog=JOB_PORTAL_DB;Integrated Security=True")
        {
            Configuration.ProxyCreationEnabled = createProxy;

        }
        
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {


            //Applicant JobApplications Foreign Keys

            modelBuilder.Entity<CompanyJobPoco>()
                .HasMany(a => a.ApplicantJobApplications)
                .WithRequired(a => a.CompanyJob)
                .HasForeignKey(a => a.Job);

            modelBuilder.Entity<ApplicantProfilePoco>()
                .HasMany(a => a.ApplicantJobApplications)
                .WithRequired(e => e.ApplicantProfile)
                .HasForeignKey(e => e.Applicant);



            //Applicant Profile Foreign Keys

            modelBuilder.Entity<SystemCountryCodePoco>()
                .HasMany(a => a.ApplicantProfiles)
                .WithRequired(a => a.SystemCountryCode)
                .HasForeignKey(a => a.Country);

            modelBuilder.Entity<SecurityLoginPoco>()
                .HasMany(a => a.ApplicantProfiles)
                .WithRequired(a => a.SecurityLogin)
                .HasForeignKey(a => a.Login);


            //ApplicantResume Foreign Keys

            modelBuilder.Entity<ApplicantProfilePoco>()
               .HasMany(a => a.ApplicantResumes)
               .WithRequired(e => e.ApplicantProfile)
               .HasForeignKey(e => e.Applicant);


            //ApplicantSkills Foregin Keys

            modelBuilder.Entity<ApplicantProfilePoco>()
                .HasMany(a => a.ApplicantSkills).
                WithRequired(a => a.ApplicantProfile)
                .HasForeignKey(a => a.Applicant);

            //ApplicantWorkHistory Foreign keys
            modelBuilder.Entity<SystemCountryCodePoco>()
                .HasMany(a => a.ApplicantWorkHistories)
                .WithRequired(a => a.SystemCountryCode)
                .HasForeignKey(a => a.CountryCode);

            modelBuilder.Entity<ApplicantProfilePoco>()
                .HasMany(a => a.ApplicantWorkHistories)
                .WithRequired(a => a.ApplicantProfile)
                .HasForeignKey(a => a.Applicant);

            //CompanyDescriptions Foreign keys

            modelBuilder.Entity<CompanyProfilePoco>()
                .HasMany(a => a.CompanyDescriptions)
                .WithRequired(a => a.CompanyProfile)
                .HasForeignKey(a => a.Company);
            modelBuilder.Entity<SystemLanguageCodePoco>()
                .HasMany(a => a.CompanyDescriptions)
                .WithRequired(a => a.SystemLanguageCode)
                .HasForeignKey(a => a.LanguageId);

            // CompanyJobEducation Foreignkeys
            modelBuilder.Entity<CompanyJobPoco>()
                .HasMany(a => a.CompanyJobEducations)
                .WithRequired(a => a.CompanyJob)
                .HasForeignKey(a => a.Job);

            //CompanyJobSkills Foregin Keys

            modelBuilder.Entity<CompanyJobPoco>()
                .HasMany(a => a.CompanyJobSkills)
                .WithRequired(a => a.CompanyJob)
                .HasForeignKey(a => a.Job);

            //CompanyJobs Foregin Keys
            modelBuilder.Entity<CompanyProfilePoco>()
                .HasMany(a => a.CompanyJobs).
                WithRequired(a => a.CompanyProfile).
                HasForeignKey(a => a.Company);

            //CompanyJobDescriptions Foregin keys

            modelBuilder.Entity<CompanyJobPoco>()
                .HasMany(a => a.CompanyJobDescriptions)
                .WithRequired(a => a.CompanyJob)
                .HasForeignKey(a => a.Job);

            //CompanyLocation Foregin Keys

            modelBuilder.Entity<CompanyProfilePoco>()
                .HasMany(a => a.CompanyLocations)
                .WithRequired(a => a.CompanyProfile)
                .HasForeignKey(a => a.Company);

            //SecurityLoginLogs Foreign Keys

            modelBuilder.Entity<SecurityLoginPoco>()
                .HasMany(a => a.SecurityLoginLogs)
                .WithRequired(a => a.SecurityLogin)
                .HasForeignKey(a => a.Login);

            //SecurityLoginRoles Foregin Keys

            modelBuilder.Entity<SecurityLoginPoco>()
                .HasMany(a => a.SecurityLoginRoles)
                .WithRequired(a => a.SecurityLogin)
                .HasForeignKey(a => a.Login);

            modelBuilder.Entity<SecurityRolePoco>()
                .HasMany(a => a.SecurityLoginsRoles)
                .WithRequired(a => a.SecurityRole)
                .HasForeignKey(a => a.Role);

            //ApplicantEducation Foregin Key



            modelBuilder.Entity<ApplicantProfilePoco>()
                .HasMany(a => a.ApplicantEducations)
                .WithRequired(e => e.ApplicantProfile)
                .HasForeignKey(e => e.Applicant);

            modelBuilder.Entity<ApplicantEducationPoco>().Ignore(t => t.TimeStamp);
            modelBuilder.Entity<ApplicantJobApplicationPoco>().Ignore(t => t.TimeStamp);
            modelBuilder.Entity<ApplicantProfilePoco>().Ignore(t => t.TimeStamp);
          
            modelBuilder.Entity<ApplicantSkillPoco>().Ignore(t => t.TimeStamp);
            modelBuilder.Entity<ApplicantWorkHistoryPoco>().Ignore(t => t.TimeStamp);
            modelBuilder.Entity<CompanyDescriptionPoco>().Ignore(t => t.TimeStamp);
            modelBuilder.Entity<CompanyJobEducationPoco>().Ignore(t => t.TimeStamp);
            modelBuilder.Entity<CompanyJobSkillPoco>().Ignore(t => t.TimeStamp);
            modelBuilder.Entity<CompanyJobPoco>().Ignore(t => t.TimeStamp);
            modelBuilder.Entity<CompanyJobDescriptionPoco>().Ignore(t => t.TimeStamp);
            modelBuilder.Entity<CompanyLocationPoco>().Ignore(t => t.TimeStamp);
            modelBuilder.Entity<CompanyProfilePoco>().Ignore(t => t.TimeStamp);
            modelBuilder.Entity<SecurityLoginPoco>().Ignore(t => t.TimeStamp);            
            modelBuilder.Entity<SecurityLoginsRolePoco>().Ignore(t => t.TimeStamp);
           
            base.OnModelCreating(modelBuilder);

        }
    }
}

